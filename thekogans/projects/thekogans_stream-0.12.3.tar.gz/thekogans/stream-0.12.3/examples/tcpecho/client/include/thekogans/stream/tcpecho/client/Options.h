// Copyright 2011 Boris Kogan (boris@thekogans.net)
//
// This file is part of libthekogans_stream.
//
// libthekogans_stream is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// libthekogans_stream is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with libthekogans_stream. If not, see <http://www.gnu.org/licenses/>.

#if !defined (__thekogans_stream_tcpecho_client_Options_h)
#define __thekogans_stream_tcpecho_client_Options_h

#include <string>
#include "thekogans/util/Types.h"
#include "thekogans/util/Singleton.h"
#include "thekogans/util/CommandLineOptions.h"
#include "thekogans/util/LoggerMgr.h"

namespace thekogans {
    namespace stream {
        namespace tcpecho {
            namespace client {

                struct Options :
                        public util::Singleton<Options>,
                        public util::CommandLineOptions {
                    bool help;
                    bool version;
                    util::ui32 logLevel;
                    std::string addr;
                    util::ui16 port;
                    util::ui32 rounds;
                    util::ui32 seed;
                    util::f32 a;
                    util::f32 b;
                    util::ui32 timeout;
                    bool async;

                    Options () :
                        help (false),
                        version (false),
                        logLevel (util::LoggerMgr::Info),
                        addr ("127.0.0.1"),
                        port (8854),
                        rounds (10),
                        seed (64),
                        a (2.0f),
                        b (0.0f),
                        timeout (3),
                        async (false) {}

                    virtual void DoOption (char option, const std::string &value);
                    virtual void DoPath (const std::string & /*path*/) {}
                };

            } // namespace client
        } // namespace tcpecho
    } // namespace stream
} // namespace thekogans

#endif // !defined (__thekogans_stream_tcpecho_client_Options_h)
